#ifndef _NUMBER_
#define _NUMBER_
#include "cocos2d.h"
USING_NS_CC;
#define MAX_LEVEL 3
class Number : public Node{
public:
	Number();
	inline int getValue(){ return value; }
	inline int getLevel(){ return level; }
	void playAppearAnimation(float Delay);
protected:
	Sprite * container;
	Sprite * background;
	Label * numberLabel;
	int value;
	bool selected;
	int level;

};
#endif