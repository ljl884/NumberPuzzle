#include "MoveableNumber.h"
#include "Helper.h"

MoveableNumber::MoveableNumber(int value)
{
	if (value < 0)
		return;

	//Init background
	this->background = Sprite::create("bg2.png");
	this->addChild(background);

	//Init Container
	
	this->container = Sprite::create("fg0.png");
	this->addChild(container);

	//Init number label
	//TODO
	this->numberLabel = Label::create();
	numberLabel->setString(Helper::int2str(value));
	numberLabel->setScale(10);
	numberLabel->setPosition(-15, 15);
	this->addChild(numberLabel);


	

}