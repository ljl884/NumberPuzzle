#include "StaticNumber.h"
#include "Helper.h"

StaticNumber::StaticNumber(int value, int level)
{
	if (value < 0 || level == 0 || level>MAX_LEVEL)
		return;

	//Init background
	this->background = Sprite::create("bg1.png");
	this->addChild(background);

	//Init Container
	switch (level)
	{
	case 1:
		this->container = Sprite::create("fg1.png");
		break;
	case 2:
		this->container = Sprite::create("fg2.png");
		break;
	case 3:
		this->container = Sprite::create("fg3.png");
		break;
	default:
		break;
	}
	this->addChild(container);

	//Init number label
	//TODO
	this->numberLabel = Label::create();
	numberLabel->setString(Helper::int2str(value));
	numberLabel->setScale(10);
	numberLabel->setPosition(-15, 15);
	this->addChild(numberLabel);


}